import os
import glob
import shutil
import platform 
import time
import datetime
import psycopg2
import pandas as pd
from sklearn.linear_model import LogisticRegression

class Pipeline:
    def __init__(self):
        self.database = 'postgres'
        self.table = 'raw_data'
        self.model = LogisticRegression()

    def train(self):
        print(f"Carregando informacoes do banco de dados")

        try:
            connection = psycopg2.connect(database=self.database, user='postgres', password='postgres', host="localhost", port=5432)
            connection.autocommit = True
        except:
            print("Nao consegui conectar ao banco de dados")
            return

        # Read data into a Pandas DataFrame
        df = pd.read_sql(f'SELECT * FROM {self.table}', con=connection)

        # Close the connection
        connection.close()

        return df