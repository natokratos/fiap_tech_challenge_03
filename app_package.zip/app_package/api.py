from fastapi import FastAPI
import os

class ApiEndpoints:
    def __init__(self):
        self.app = FastAPI()
        try:
            if os.environ['AWS_ENDPOINT_URL']:
                self.aws_endpoint = os.environ['AWS_ENDPOINT_URL']
        except KeyError as e:
            self.aws_endpoint = 'http://localhost:4566'
        print(f"AWS_ENDPOINT_URL [ {self.aws_endpoint} ]")
        
        @self.app.get("/")
        async def read_root():
            return {"API": "V1"}
        
        @self.app.get("/train")
        async def train(self):
            print(f"TRAIN!")

        @self.app.get("/predict")
        def predict(self):
            print(f"PREDICT!")
        
server = ApiEndpoints()