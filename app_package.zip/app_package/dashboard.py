import requests
import matplotlib.pyplot as plt

class Dashboard:

    def __init__(self):
        self.url = 'http://localhost:8080'
        self.train_error_message = f"Nao foi possivel obter resposta do endereco [{self.url}/train]"
        self.predict_error_message = f"Nao foi possivel obter resposta do endereco [{self.url}/predict]"
        def run():
            try:
                response = requests.post(f"{url}/train")
                if response.status_code != 200:
                    print(f"{self.train_error_message} STATUS CODE [{response.status_code}]")
                    exit(1)
            except:
                print(f"{self.train_error_message}")
                exit(1)
            
            try:
                response = requests.post(f"{url}/predict")
                if response.status_code != 200:
                    print(f"{self.predict_error_message} STATUS CODE [{response.status_code}]")
                    exit(1)

                y_pred = ",".join(" ".join(response.text.split(" ")[2:]).rsplit(",")[:-6]).strip()
                metric_date = ",".join(response.text.rsplit(",")[-6:-3]).strip()
                mse = ",".join(response.text.rsplit(",")[-3:-2]).strip()
                rmse = ",".join(response.text.rsplit(",")[-2:-1]).strip()
                mape = ",".join(t.rsplit(",")[-1:]).strip().strip(")")
            except:
                print(f"{self.predict_error_message}")
                exit(1)

            print('The coeffitient is: {0}'.format(trend.coef_))
            print('The intercept is: {0}'.format(trend.intercept_))
            print('The correlation of the values is: {0}'.format(r2_score(scatter_y_test, scatter_y_pred)))
            plt.scatter(scatter_x_test, scatter_y_test,  color='black')
            plt.plot(scatter_x_test, scatter_y_pred, color='blue', linewidth=1)
            plt.xticks(())
            plt.yticks(())
            plt.show()